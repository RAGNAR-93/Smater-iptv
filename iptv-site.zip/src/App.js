export default function IPTVWebsite() {
  return (
    <div className="font-sans text-gray-800">
      <header className="bg-black text-white p-6 text-center text-3xl font-bold shadow-md">
        IPTV World - Streaming Sans Limite
      </header>
      <section className="p-8 text-center bg-gradient-to-b from-gray-100 to-white">
        <h2 className="text-2xl font-semibold mb-4">Bienvenue sur notre plateforme IPTV</h2>
        <p className="text-lg">Profitez de chaînes TV du monde entier, les derniers films et séries, en haute qualité.</p>
      </section>
    </div>
  );
}
